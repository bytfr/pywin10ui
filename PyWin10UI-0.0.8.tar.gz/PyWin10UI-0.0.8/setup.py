#coding:utf-8
from setuptools import setup

setup(name='PyWin10UI',
      version='0.0.8',
      description='2021/12/30',
      url='https://github.com/bytfr/pywin10ui',
      author='bytfr 啃竹子',
      author_email='2678509244@qq.com',
      license='MIT',
      packages=['pywin10ui'])